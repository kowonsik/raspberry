/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2010 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include "M051Series.h"

#define PLLCON_SETTING      SYSCLK_PLLCON_50MHz_XTAL
#define PLL_CLOCK           22118400

void CKO_Init(void)
{
    /* CKO = HCLK / 2^(1+1) */
    SYS_EnableCKO(SYSCLK_CLKSEL2_FRQDIV_HCLK, 3);

}
void ADC_disable(void)
{
	ADC->ADCR = 0;
  
	ADC->ADCHER = 0;
}
void ADC_Init(void)
{
 
		///ADC Port Enable
	/* Set the ADC operation mode as continous scan, input mode as single-end and enable the ADC converter */
  ADC->ADCR = (ADC_ADCR_ADMD_SINGLE_CYCLE | ADC_ADCR_DIFFEN_SINGLE_END | ADC_ADCR_ADEN_CONVERTER_ENABLE);
  
_ADC_SET_CHANNEL(0xFF);

	//ADC->ADCHER |= ADC_ADCHER_PRESEL_INT_BANDGAP ;
	
}

void SPI0_Init(void)
{
    /* Initial SPI data format and SPI clock */
    /* SPI clock idle low. 32-bit data output at clock falling and latched at clock rising. */    
    SPI0->CNTRL   = SPI_CNTRL_CLK_IDLE_LOW | SPI_CNTRL_TX_FALLING | 
                    SPI_CNTRL_RX_RISING | SPI_CNTRL_TX_BIT_LEN(32);

    /* SPI clock freq = system clock / ((3+1)*2) */
    SPI0->DIVIDER = SPI_DIVIDER_DIV(3); 
    
    /* Enable automatic slave select control and set it as active low */
    SPI0->SSR = SPI_SSR_HW_AUTO_ACTIVE_LOW;
}

void SPI1_Init(void)
{
  
	/*---------------------------------------------------------------------------------------------------------*/
/* Init SPI                                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
	
     /* Initial SPI data format and SPI clock */
    /* Configure SPI0 as a master, clock idle low, falling clock edge Tx, rising edge Rx and 32-bit transaction */
    SPI1->CNTRL = SPI_CNTRL_MASTER_MODE | SPI_CNTRL_CLK_IDLE_LOW | SPI_CNTRL_TX_FALLING |
                     SPI_CNTRL_RX_RISING | SPI_CNTRL_TX_BIT_LEN(32);
 
    /* SPI clock freq = system clock / ((3+1)*2) */
    SPI1->DIVIDER = SPI_DIVIDER_DIV(11); 
	   
    /* Enable automatic slave select control and set it as active low */
    SPI1->SSR = SPI_SSR_HW_AUTO_ACTIVE_LOW;
}


void I2C0_Init(void)
{
    /* Enable I2C0 Controller */
    I2C0->I2CON = I2C_I2CON_ENS1_Msk;
    
    /* I2C0 clock divider, I2C Bus Clock = PCLK / (4*125) */
    I2C0->I2CLK = I2C_I2CLK_DIV4(125);

    /* Set I2C0 4 Slave Addresses */            
    _I2C_SET_SLAVE_ADDRESS_0(I2C0, 0x15);   /* Slave Address : 0x15 */
    _I2C_SET_SLAVE_ADDRESS_1(I2C0, 0x35);   /* Slave Address : 0x35 */
    _I2C_SET_SLAVE_ADDRESS_2(I2C0, 0x55);   /* Slave Address : 0x55 */
    _I2C_SET_SLAVE_ADDRESS_3(I2C0, 0x75);   /* Slave Address : 0x75 */

    /* Enable I2C0 interrupt and set corresponding NVIC bit */
    //I2C->I2CON |= I2C_I2CON_EI_Msk;
    //NVIC_EnableIRQ(I2C0_IRQn);
}

void EBI_Init(void)
{
    /* Enable EBI, data width = 16-bit, EBI MCLK = HCLK / 4 */
    EBI->EBICON = EBI_EBICON_ExtEN_Msk | EBI_EBICON_ExtBW16_Msk | EBI_EBICON_MCLKDIV_4;
}

void PWMA_disable(void)
{
	PWMA->PCR  = 0;
	PWMA->POE = 0;
}


void PWMA_Init(void)
{
    /* PWM Timer0: Clk = HCLK / 120 / 16, Freq = clk / 6250, dute cycle = 3125/6250 % */
    /* PWM Timer1: Clk = HCLK / 120 / 16, Freq = clk / 3125, dute cycle = 1563/3125 % */
    /* PWM Timer2: Clk = HCLK / 60 / 16, Freq = clk / 3125, dute cycle = 1563/3125 % */
    /* PWM Timer3: Clk = HCLK / 60 / 1, Freq = clk / 50, dute cycle = 25/50 % */
    /* PWM0 = 12000000 / 120 / 16 / 6250 =    1Hz */
    /* PWM1 = 12000000 / 120 / 16 / 3125 =    2Hz */
    /* PWM2 = 12000000 /  60 / 16 / 3125 =    4Hz */
    /* PWM3 = 12000000 /  60 /  1 /   50 = 4000Hz */
	
    PWMA->PPR = PWM_PPR_CP01(2) | PWM_PPR_CP23(16);
    PWMA->CSR = PWM_CSR_CSR0(PWM_CSR_DIV1) | PWM_CSR_CSR1(PWM_CSR_DIV1) |
                   PWM_CSR_CSR2(PWM_CSR_DIV1) | PWM_CSR_CSR3(PWM_CSR_DIV1);

    /* Enable PWM0, PWM1, PWM2, PWM3 counter. We must set PWM mode before setting CNR, CMR. */
    PWMA->PCR = PWM_PCR_CH0EN_Msk | PWM_PCR_CH0MOD_AUTO_RELOAD ;

	  // CNR 0
  /*  PWMA->CNR0= 5000 - 1;
    PWMA->CMR0= 2500 - 1;
	 
    PWMA->CNR1= 3125 - 1;
    PWMA->CMR1= 1563 - 1;
	 
    PWMA->CNR2= 3125 - 1;
    PWMA->CMR2= 1563 - 1;
	 
    PWMA->CNR3= 50 - 1;
    PWMA->CMR3= 25 - 1;
*/
    /* Enable PWM channle 0, 1, 2, 3 Output */
    PWMA->POE = PWM_POE_PWM0_Msk  ;

	//	PWMA->PCR |=  PWM_PCR_CH0EN_ENABLE;
 //	  SYS->P2_MFP &= ~SYS_MFP_P20_GPIO;
//		SYS->P2_MFP |= SYS_MFP_P20_PWM0;

}


void PWMB_Init(void)
{
    /* PWM Timer0: Clk = HCLK / 120 / 16, Freq = clk / 6250, dute cycle = 3125/6250 % */
    /* PWM Timer1: Clk = HCLK / 120 / 16, Freq = clk / 3125, dute cycle = 1563/3125 % */
    /* PWM Timer2: Clk = HCLK / 60 / 16, Freq = clk / 3125, dute cycle = 1563/3125 % */
    /* PWM Timer3: Clk = HCLK / 60 / 1, Freq = clk / 50, dute cycle = 25/50 % */
    /* PWM0 = 12000000 / 120 / 16 / 6250 =    1Hz */
    /* PWM1 = 12000000 / 120 / 16 / 3125 =    2Hz */
    /* PWM2 = 12000000 /  60 / 16 / 3125 =    4Hz */
    /* PWM3 = 12000000 /  60 /  1 /   50 = 4000Hz */
    PWMB->PPR = PWM_PPR_CP01(2) | PWM_PPR_CP23(16);
    PWMB->CSR = PWM_CSR_CSR0(PWM_CSR_DIV1) | PWM_CSR_CSR1(PWM_CSR_DIV1) |
                   PWM_CSR_CSR2(PWM_CSR_DIV1) | PWM_CSR_CSR3(PWM_CSR_DIV1);

    /* Enable PWM0, PWM1, PWM2, PWM3 counter. We must set PWM mode before setting CNR, CMR. */
    PWMB->PCR = PWM_PCR_CH1EN_Msk | PWM_PCR_CH0MOD_AUTO_RELOAD | 
                   PWM_PCR_CH1EN_Msk | PWM_PCR_CH1MOD_AUTO_RELOAD |
                   PWM_PCR_CH2EN_Msk | PWM_PCR_CH2MOD_AUTO_RELOAD |
                   PWM_PCR_CH3EN_Msk | PWM_PCR_CH3MOD_AUTO_RELOAD;

    PWMB->CNR0= 5000 - 1;
    PWMB->CMR0= 2500 - 1;
	 
    PWMB->CNR1= 500 - 1;
    PWMB->CMR1= 250 - 1;
	 
    PWMB->CNR2= 5000 - 1;
    PWMB->CMR2= 2500 - 1;
	 
    PWMB->CNR3= 5000 - 1;
    PWMB->CMR3= 2500 - 1;

    /* Enable PWM channle 0, 1, 2, 3 Output */
    PWMB->POE = PWM_POE_PWM0_Msk | PWM_POE_PWM1_Msk | PWM_POE_PWM2_Msk | PWM_POE_PWM3_Msk;


    /* Enable PWM channle 0, 1, 2, 3 Output */
  //  PWMB->POE =  PWM_POE_PWM1_Msk ;

	//	PWMB->PCR |=  PWM_PCR_CH1EN_ENABLE;
 	// SYS->P2_MFP &= ~SYS_MFP_P25_GPIO;
	//	SYS->P2_MFP |= SYS_MFP_P25_PWM5;
}


void TMR0_Init(void)
{
    TIMER0->TCSR = TIMER_TCSR_INIT_IE(22);
    TIMER0->TCMPR = 100; // 22MHz / 12 / 100 = 10000Hz
    NVIC_EnableIRQ(TMR0_IRQn);
}

void TMR1_Init(void)
{
    TIMER1->TCSR = TIMER_TCSR_INIT_IE(12);
    TIMER1->TCMPR = 10000; // 12MHz / 12 / 10000 = 100Hz

    //NVIC_EnableIRQ(TMR0_IRQn);
}


void GPIO_Init(void)
{
  _GPIO_SET_PIN_MODE(P2, 0, GPIO_PMD_OUTPUT);
  _GPIO_SET_PIN_MODE(P2, 1, GPIO_PMD_OUTPUT);
  _GPIO_SET_PIN_MODE(P3, 7, GPIO_PMD_OUTPUT);

	_GPIO_SET_PIN_MODE(P2, 3, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 4, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P4, 0, GPIO_PMD_OUTPUT);
	
	_GPIO_SET_PIN_MODE(P2, 5, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 6, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 7, GPIO_PMD_OUTPUT);
	
	_GPIO_SET_PIN_MODE(P0, 4, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 5, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 7, GPIO_PMD_OUTPUT);
  _GPIO_SET_PIN_MODE(P0, 6, GPIO_PMD_INPUT);
	
	_GPIO_SET_PIN_MODE(P4, 3, GPIO_PMD_INPUT);
	_GPIO_SET_PIN_MODE(P3, 0, GPIO_PMD_OUTPUT);
	
/*	_GPIO_SET_PIN_MODE(P4, 0, GPIO_PMD_OUTPUT);	
	_GPIO_SET_PIN_MODE(P2, 4, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 3, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P4, 2, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 0, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 1, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 2, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 3, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 4, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 5, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 6, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P0, 7, GPIO_PMD_OUTPUT);


	_GPIO_SET_PIN_MODE(P4, 4, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 7, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P2, 6, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P4, 3, GPIO_PMD_OUTPUT);

	_GPIO_SET_PIN_MODE(P2, 0, GPIO_PMD_OUTPUT);
	_GPIO_SET_PIN_MODE(P1, 1, GPIO_PMD_OUTPUT);
*/  	                                 
	//_GPIO_SET_PIN_MODE(P3, 6, GPIO_PMD_OUTPUT);


// Enable debunce function of P3.2 (EINT0) 
 
	_GPIO_SET_PIN_MODE(P3, 2, GPIO_PMD_INPUT);
	 P3->DBEN = GPIO_DBEN_ENABLE(2);

    GPIO->DBNCECON = GPIO_DBNCECON_DBCLKSRC_IRC10K | GPIO_DBNCECON_DBCLKSEL_64; // Set debounce time. it is about 6.4 ms 
    GPIO_EnableInt(P3, 2, GPIO_INT_RISING);//Enable P3.2 to be EINT0
    NVIC_EnableIRQ(EINT0_IRQn);

    _GPIO_SET_PIN_MODE(P4, 3, GPIO_PMD_QUASI);
    GPIO_EnableInt(P4, 3, GPIO_INT_FALLING);
    NVIC_EnableIRQ(GPIO_P2P3P4_IRQn);

}

void UART0_Init(void)
{
    /* Set 9600 baudrate according to 50MHz system clock */
    UART0->BAUD = UART_BAUD_MODE2 | UART_BAUD_DIV_MODE2(PLL_CLOCK, 38400);
    _UART_SET_DATA_FORMAT(UART0, UART_WORD_LEN_8 | UART_PARITY_NONE | UART_STOP_BIT_1);

	_UART_ENABLE_INT(UART0, (UART_IER_RDA_IEN_Msk |  UART_IER_RTO_IEN_Msk));
	  NVIC_EnableIRQ(UART0_IRQn);
}

void UART1_Init(void)
{
    /* Set 115200 baudrate according to 50MHz system clock */
    UART1->BAUD = UART_BAUD_MODE2 | UART_BAUD_DIV_MODE2(PLL_CLOCK,38400);
    _UART_SET_DATA_FORMAT(UART1, UART_WORD_LEN_8 | UART_PARITY_NONE | UART_STOP_BIT_1);
  	_UART_ENABLE_INT(UART1, (UART_IER_RDA_IEN_Msk |  UART_IER_RTO_IEN_Msk));
	  NVIC_EnableIRQ(UART1_IRQn);
}

void SYS_Init(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

/*---------------------------------------------------------------------------------------------------------*/
/* Init System Clock                                                                                       */
/*---------------------------------------------------------------------------------------------------------*/

    /* Enable Internal RC clock */
    SYSCLK->PWRCON |= SYSCLK_PWRCON_IRC22M_EN_Msk;
    /* Waiting for IRC22M clock ready */
    SYS_WaitingForClockReady(SYSCLK_CLKSTATUS_IRC22M_STB_Msk);

    /* Switch HCLK clock source to internal RC */
    SYSCLK->CLKSEL0 = SYSCLK_CLKSEL0_HCLK_IRC22M;

    /* Set PLL to power down mode and PLL_STB bit in CLKSTATUS register will be cleared by hardware.*/
    SYSCLK->PLLCON |= SYSCLK_PLLCON_PD_Msk;

    /* Enable external 12MHz XTAL, internal 22.1184MHz, 10kHz */
    SYSCLK->PWRCON |= /*SYSCLK_PWRCON_XTL12M_EN_Msk |*/ SYSCLK_PWRCON_IRC22M_EN_Msk | SYSCLK_PWRCON_IRC10K_EN_Msk;

    /* Enable PLL and Set PLL frequency */        // Disable PLL
    //SYSCLK->PLLCON = PLLCON_SETTING;
    
    /* Waiting for clock ready */
//    SYS_WaitingForClockReady(SYSCLK_CLKSTATUS_PLL_STB_Msk | SYSCLK_CLKSTATUS_XTL12M_STB_Msk  | SYSCLK_CLKSTATUS_IRC10K_STB_Msk |
//                             SYSCLK_CLKSTATUS_IRC22M_STB_Msk);

    /* Switch HCLK clock source to PLL, STCLK to HCLK/2 */
//    SYSCLK->CLKSEL0 = SYSCLK_CLKSEL0_STCLK_XTAL | SYSCLK_CLKSEL0_HCLK_XTAL;

    /* Enable IP clock */        
 	
/*	 SYSCLK->APBCLK = SYSCLK_APBCLK_ACMP_EN_Msk | SYSCLK_APBCLK_ADC_EN_Msk | SYSCLK_APBCLK_PWM67_EN_Msk | 
                        SYSCLK_APBCLK_PWM45_EN_Msk | SYSCLK_APBCLK_PWM23_EN_Msk | SYSCLK_APBCLK_PWM01_EN_Msk |
                        SYSCLK_APBCLK_UART1_EN_Msk | SYSCLK_APBCLK_UART0_EN_Msk | SYSCLK_APBCLK_SPI1_EN_Msk |
                        SYSCLK_APBCLK_SPI0_EN_Msk | SYSCLK_APBCLK_I2C0_EN_Msk | SYSCLK_APBCLK_FDIV_EN_Msk |
                        SYSCLK_APBCLK_TMR3_EN_Msk | SYSCLK_APBCLK_TMR2_EN_Msk | SYSCLK_APBCLK_TMR1_EN_Msk |
                        SYSCLK_APBCLK_TMR0_EN_Msk | SYSCLK_APBCLK_WDT_EN_Msk; 
*/
 SYSCLK->APBCLK = SYSCLK_APBCLK_ADC_EN_Msk |SYSCLK_APBCLK_PWM01_EN_Msk |SYSCLK_APBCLK_PWM45_EN_Msk |
                        SYSCLK_APBCLK_UART1_EN_Msk | SYSCLK_APBCLK_UART0_EN_Msk | SYSCLK_APBCLK_FDIV_EN_Msk |
                        SYSCLK_APBCLK_TMR3_EN_Msk | SYSCLK_APBCLK_TMR2_EN_Msk | SYSCLK_APBCLK_TMR1_EN_Msk |
                        SYSCLK_APBCLK_TMR0_EN_Msk | SYSCLK_APBCLK_WDT_EN_Msk| SYSCLK_APBCLK_SPI1_EN_Msk; 

    /* Select IP clock source */
  
   SYSCLK->CLKSEL1 = SYSCLK_CLKSEL1_PWM23_IRC22M | SYSCLK_CLKSEL1_PWM01_IRC22M | SYSCLK_CLKSEL1_UART_IRC22M |
                         SYSCLK_CLKSEL1_TMR3_IRC22M | SYSCLK_CLKSEL1_TMR2_IRC22M | SYSCLK_CLKSEL1_TMR1_IRC22M |
                         SYSCLK_CLKSEL1_TMR0_IRC22M | SYSCLK_CLKSEL1_ADC_IRC22M | SYSCLK_CLKSEL1_WDT_IRC10K;

    SYSCLK->CLKSEL2 = SYSCLK_CLKSEL2_PWM67_IRC22M | SYSCLK_CLKSEL2_PWM45_IRC22M| SYSCLK_CLKSEL2_FRQDIV_IRC22M;
    
        
    /* IP clock divider */
    SYSCLK->CLKDIV = SYSCLK_CLKDIV_ADC(3) |  // ADC clock = ADC clock source /3
                        SYSCLK_CLKDIV_UART(1) | // UART clock = UART clock source / 1
                        SYSCLK_CLKDIV_HCLK(1);  // HCLK clock = HCLK clock source / 1


    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    //SystemCoreClockUpdate(); 
    PllClock        = PLL_CLOCK;            // PLL
    SystemCoreClock = PLL_CLOCK / 1;        // HCLK
    CyclesPerUs     = PLL_CLOCK / 1000000;  // For SYS_SysTickDelay()

/*---------------------------------------------------------------------------------------------------------*/
/* Init I/O Multi-function                                                                                 */
/*---------------------------------------------------------------------------------------------------------*/


    SYS->P0_MFP = SYS_MFP_P00_GPIO | SYS_MFP_P01_GPIO | SYS_MFP_P02_GPIO | SYS_MFP_P03_GPIO |
                   // SYS_MFP_P04_SPISS1 | SYS_MFP_P05_MOSI_1 | SYS_MFP_P06_MISO_1 | SYS_MFP_P07_SPICLK1;
										 SYS_MFP_P04_GPIO | SYS_MFP_P05_GPIO | SYS_MFP_P06_GPIO | SYS_MFP_P07_GPIO;

    SYS->P1_MFP = SYS_MFP_P10_AIN0 | SYS_MFP_P11_AIN1 | SYS_MFP_P12_RXD1 | SYS_MFP_P13_TXD1 |
                     SYS_MFP_P14_AIN4 | SYS_MFP_P15_AIN5 | SYS_MFP_P16_AIN6 | SYS_MFP_P17_AIN7;

    SYS->P2_MFP = SYS_MFP_P20_GPIO | SYS_MFP_P22_GPIO  | SYS_MFP_P22_GPIO | SYS_MFP_P23_GPIO | 
		 					SYS_MFP_P24_GPIO | SYS_MFP_P25_GPIO | SYS_MFP_P26_GPIO | SYS_MFP_P27_GPIO;

    SYS->P3_MFP = SYS_MFP_P30_RXD0 | SYS_MFP_P31_TXD0 |SYS_MFP_P32_INT0 | SYS_MFP_P33_GPIO |
                     SYS_MFP_P34_GPIO | SYS_MFP_P35_GPIO | SYS_MFP_P36_GPIO | SYS_MFP_P37_GPIO;
                     
    SYS->P4_MFP = SYS_MFP_P40_GPIO | SYS_MFP_P41_GPIO | SYS_MFP_P42_GPIO | SYS_MFP_P43_GPIO |
                     SYS_MFP_P44_GPIO | SYS_MFP_P45_GPIO | SYS_MFP_P46_GPIO | SYS_MFP_P47_GPIO;
                     
    /* Lock protected registers */
    SYS_LockReg();
}
