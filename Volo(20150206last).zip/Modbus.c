/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2010 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include "M051Series.h"

 uint16_t CRC16(uint8_t *buff, uint16_t num)
{
	uint16_t CRC = 0xFFFF; 
	int i; 

	while (num--) 
	{ 
			CRC ^= *buff++; 
			for (i = 0; i < 8; i++) 
			{ 
				if (CRC & 1) 
				{ 
					CRC >>= 1; 
					CRC ^= 0xA001; 
				} 
				else 
				{ 
					CRC >>= 1; 
				} 
			} 
	} 
	return CRC; 
}
