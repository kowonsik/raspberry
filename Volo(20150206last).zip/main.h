#ifndef	__MAIN_H__
#define	__MAIN_H__
#define	MS_TIMER		(nMsTimer)

typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;

int CheckTimeOver(u32 ms, u32 OldTime);
extern volatile u32	nMsTimer;

#endif
