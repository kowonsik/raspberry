/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2010 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
#include <stdio.h>
#include "M051Series.h"
#include "initialization.h"
#include "main.h"
#include "Modbus.c"


#define PRINTF_EN      1
#define DATAFLASH_BASE   0x0001F000
#define PAGE_SIZE       FMC_FLASH_PAGE_SIZE
#define SWVERSION      1000
#define CURRENTSTEP  5  // 0.05���� ��� 10 , 0.1���� ��� 5 

#define SPI_DIV   1
#define p_LED1				GPIO_PIN_DATA(2, 5)
#define p_LED2				GPIO_PIN_DATA(2, 6)
#define p_LED3				GPIO_PIN_DATA(2, 7)

#define p_LEDG				GPIO_PIN_DATA(2, 5)
#define p_LEDR				GPIO_PIN_DATA(2, 6)
#define p_LEDB				GPIO_PIN_DATA(2, 7)
//#define p_RXD0				 GPIO_PIN_DATA(3, 0)
#define p_BUZZ			  GPIO_PIN_DATA(2, 0)

#define p_sCS				  GPIO_PIN_DATA(0, 4)
#define p_sDin				  GPIO_PIN_DATA(0, 6)
#define p_sDout			  GPIO_PIN_DATA(0, 5)
#define p_sCLK			  GPIO_PIN_DATA(0, 7)
//#define p_sCAL1		  GPIO_PIN_DATA(2, 0)
//#define p_sCAL2    	GPIO_PIN_DATA(2, 1)
#define _DO1 256
#define _LE1 288
#define _MI1 320
#define _PA1 341
#define _SOL1 384
#define _LA1 426
#define _SI1 480
#define _DO2 512





#define p_sRLYSW	GPIO_PIN_DATA(3, 7)
#define p_ZXIN				GPIO_PIN_DATA(4, 3)

#define p_sUSERSW	GPIO_PIN_DATA(3, 2)


/*
#define p_RSel1				GPIO_PIN_DATA(4, 5)
#define p_RSel2				GPIO_PIN_DATA(2, 7)
#define p_RSel3			  GPIO_PIN_DATA(2, 6)
#define p_RSel4			  GPIO_PIN_DATA(2, 5)
#define p_RSel5			  GPIO_PIN_DATA(4, 4)
#define p_RSel6			  GPIO_PIN_DATA(0, 7)
*/

#define p_ADC_TEMP_DATA 					_ADC_GET_CONVERSION_DATA(1)
#define p_ADC_VOLTAGE_DATA 		_ADC_GET_CONVERSION_DATA(0)
#define p_ADC_BAT1DV_DATA 			_ADC_GET_CONVERSION_DATA(5)
#define p_ADC_BAT2DV_DATA 			_ADC_GET_CONVERSION_DATA(4)
#define p_ADC_BAT3DV_DATA 			_ADC_GET_CONVERSION_DATA(6)
#define p_ADC_BAT4DV_DATA 			_ADC_GET_CONVERSION_DATA(2)
#define p_ADC_CURRENT_DATA 		_ADC_GET_CONVERSION_DATA(3)
#define p_ADC_VREF_DATA 					_ADC_GET_CONVERSION_DATA(7)

void SerialProtocal(uint8_t u8InChar);

enum{Idle,Ready,Mes1,Mes2}seq;

volatile u32	nMsTimer;
void SaveParam(void);
void SaveSysParam(void);
void LoadParam(void);
void UART0_TEST_HANDLE();
void UART1_TEST_HANDLE();
int spiRead(uint8_t Address, uint8_t Len);
void spiWrite(uint8_t Address, int Data,uint8_t Len);
uint32_t 	GetAdcValue(uint8_t  gCHNum,uint16_t AccCnt );
void TMR0_IRQHandler(void)
{
	nMsTimer++;
	TIMER0->TISR = 0x01;
}
void Sleep(uint32_t ms)
{
    int32_t i;    
    for(i=0;i<ms;i++)
        SYS_SysTickDelay(1100);    
}

void usSleep(uint32_t us)
{
    int32_t i; 
	 
    for(i=0;i<us/10;i++)
        SYS_SysTickDelay(9);    
}
////////////////////////////////UART Serial Read

#define RXBUFSIZE 256

#define BINRXBUFSIZE 128
#define BINTXBUFSIZE 128

#define SERIALTIMEOUT 30
/*---------------------------------------------------------------------------------------------------------*/
/* Global variables                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
uint8_t g_u8SendData[12] ={0};
uint8_t g_u8RecData[RXBUFSIZE]  ={0};
uint8_t g_u8RCO2Data[128]  ={0};

uint8_t g_u8BinRxData[BINRXBUFSIZE]  ={0};
uint8_t g_u8BinTxData[BINTXBUFSIZE]  ={0};
uint16_t  g_BinTXCount = 0;

uint8_t g_u8CommData[4]  ={0,0,0,0};

volatile uint32_t g_u32comRbytes = 0;        
volatile uint32_t g_u32comRhead  = 0;
volatile uint32_t g_u32comRtail  = 0;
volatile int32_t g_bWait         = TRUE;
volatile int32_t g_i32pointer = 0;
		uint32_t	pulse_cnt 	= 0;

		uint8_t nsp = 1;
	
uint32_t HCnt = 0;

uint32_t DeltaVH;
uint32_t VoltageH;
uint32_t CurrentH;

uint32_t LCnt = 0;
uint32_t DeltaV1L,DeltaV2L,DeltaV3L,DeltaV4L;
uint32_t DeltaV1H,DeltaV2H,DeltaV3H,DeltaV4H;

uint32_t Voltage = 0;
uint32_t RSSel 	 = 0;
uint32_t CO2_Val 	 = 0;

uint8_t Terminal_Enable = 1;

	double pValA = 0;
	double pValVA = 0;
	double pValV = 0;
  double pValFreq = 0;
	u8 pAVGCNT = 3;
	
	u8 p_RLYSW = 0;
	int checkperiod = 20000;//1s

	// �Ķ���� �ʱ�ȭ//////////////////////////////////
	
struct MesParam
	{
		  uint16_t  ResSel;
			uint16_t  SetVoltage;
	};

struct SysParam
	{
			uint16_t  sa;      // saddress
		  uint16_t  HWver;
			uint16_t  SWver;
			uint16_t  temp;
	};

struct MesData
	{
			int  Voltz;
			int  Current;
		  int  Vref_Volt;
		  int  LV_Volt;
	};	

struct OpParam
	{		
			uint16_t wen;
			uint16_t  Reset;
			uint16_t  SaveFlash;
		  uint16_t  Temp; 
			uint16_t  PDMode;
	    uint16_t  restoreFactory;		
//			uint16_t  temp;	
	};
	
	
	struct MesParam _mp={0,};
	struct SysParam _sp={0,};
	struct MesData _md={0,};
	struct OpParam _op={0,};
	
	
	void LoadParam(void)
	{
								uint32_t *buf;
								uint32_t u32Data,i;
								SYS_UnlockReg();
								FMC->ISPCON = FMC_ISPCON_LDUEN_Msk | FMC_ISPCON_ISPEN_Msk;
	 					   _FMC_ENABLE_LOW_FREQ_OPTIMIZE_MODE();

					if(FMC_Read(DATAFLASH_BASE + PAGE_SIZE) == 0xFFFFFFFF)
						{

								_sp.SWver =  SWVERSION ;
								_sp.HWver	 = 0;
	
							  SaveParam();
								//SaveSysParam();
								return;
							}
						
							buf = (uint32_t*)&_sp;
																
								for ( i = 0 ; i <sizeof(_sp) ; i += 4 )
                {
									u32Data = FMC_Read(DATAFLASH_BASE + PAGE_SIZE + i);
									*(buf+ i/4) = u32Data;
								}
							
								_sp.SWver =  SWVERSION ;
								SYS_LockReg();
	}
	
	void SaveSysParam(void)
	{
							uint32_t u32Data,i;	
								uint32_t *buf;
							
							SYS_UnlockReg();
				
							 FMC_Erase(DATAFLASH_BASE + PAGE_SIZE);
								Sleep(50);
									
								buf = (uint32_t*)&_sp;
		
								for (i = 0;i < sizeof(_sp) ; i += 4)
								{
									u32Data = 	*(buf+ i/4);
									FMC_Write(DATAFLASH_BASE + PAGE_SIZE + i , u32Data);
								}
							
						SYS_LockReg();	
}
	void SaveParam(void)
	{
							uint32_t u32Data,i;	
							uint32_t *buf;
							
						SYS_UnlockReg();
		
							FMC_Erase(DATAFLASH_BASE + PAGE_SIZE);
							Sleep(50);
										
							buf = (uint32_t*)&_sp;
				
							for (i = 0;i < sizeof(_sp) ; i += 4)
							{
									u32Data = 	*(buf+ i/4);
									FMC_Write(DATAFLASH_BASE + PAGE_SIZE + i , u32Data);		
							}
	
								
		SYS_LockReg();
		
	}

void GPIOP2P3P4_IRQHandler(void)
{
	static u32 timer = 0;
	static u32 ZXCnt = 0;//1s
  static u8 pRLYSW_P= 0;
	static u32 dlyval = 0;

	
    /* To check if P4.3 interrupt occurred */
    if (P4->ISRC & GPIO_ISRC_ISRC3)
    {

				int PtimeVal;
				P4->ISRC = GPIO_ISRC_ISRC3;	
				ZXCnt++;
				
				PtimeVal = CheckTimeOver(checkperiod, timer);			
					
			  if(p_RLYSW != pRLYSW_P)
				{

					dlyval+=500;
					if(dlyval>10000)dlyval = 0;

				//	if(pValFreq>55)usSleep(7000);	
				//   else Sleep(10400);
					
					 p_sRLYSW = p_RLYSW;
			     pRLYSW_P = p_RLYSW;
				}

			  if(!PtimeVal) return;
				timer = MS_TIMER; 
			
				if(ZXCnt>0)
				{
							pValA = (spiRead(0x3,3) *10000)/(double)PtimeVal; 
//							pValA = (double)PtimeVal; 
							pValVA = (spiRead(0x6,3) *10000)/(double)PtimeVal; 
							pValV = spiRead(23,3); 
							
					    pValFreq = (ZXCnt*10000)/(double)PtimeVal;
							if(pValA>4000)pValA=0;
							pValA/=2.35;
							pValV*=0.000310;

							//if(pValFreq>55)	
								pValVA/=1.94345;
							  pValVA+=(pValVA-18);
							  if(pValVA<0)pValVA=0.0;
					    //else pValVA/=1.9928;
							

					
						if(Terminal_Enable)
						{
							double PF = (pValA*100)/(pValVA );//> 18 ? pValVA : pValVA-9);
							if(PF<=0.009)PF = 0;
							printf("PA : %4.2f W PV : %4.2f W PF : %4.2f Hz AV-V %4.2f V PF : %d %\n",pValA,pValVA,pValFreq,pValV,(int)PF);
						}							
						ZXCnt = 0;  
				}
		}
		else
    {
        /* Un-expected interrupt. Just clear all PORT2, PORT3 and PORT4 interrupts */
    	P2->ISRC = P2->ISRC;
    	P3->ISRC = P3->ISRC;
    	P4->ISRC = P4->ISRC;
    }
}
	
///////////////////////////////////////////////////

void EINT0_IRQHandler(void)
{
	/* For P3.2, clear the INT flag */
		P3->ISRC = GPIO_ISRC_ISRC2;

	
	
	if(p_RLYSW == 0) p_RLYSW= 1;
	else p_RLYSW= 0;
}

int GetIntVal(char * val)
{
	int intdata=0;
	int i = 0;
	
	uint32_t nLen = g_i32pointer - 3;
	int  sign = 1;
	
	if(nLen>RXBUFSIZE)return 0;
	for(i=0 ; i<nLen  ; i++)
	{
		if(i==0)
		{
				if(g_u8RecData[0] == '-')
				{
					sign = -1;
					continue;
				}
				else if(g_u8RecData[0] == '+')continue;				
		}
		
			
    if(i==nLen-1)
		{	
		 intdata += (g_u8RecData[i]-'0');
		}
		else   
			{
			  intdata += (g_u8RecData[i]-'0');
				intdata *=10;
			};
	}

	return intdata*sign;
}

void ADC_IRQHandler(void)
{
		return;
 
}

void PrintInitText (void)
{
if(!Terminal_Enable)return;
	#ifdef PRINTF_EN 
	   printf("+-----------------------------------------------------------+\n");
    printf("|               UART  Program                         																			 \n");	
    printf("+-----------------------------------------------------------+\n");
	  printf("|  **command List ** [ESC Key : Cancel] 	     																 \n");
	  printf("|  >h  : help command List  \n");
	  printf("|  >rst  : system reset \n");
	  printf("|  >ini : system restore \n");
	  printf("|  >gmn : Get Model Number\n");
	
    printf("|  >spd  : save Parameter to flash memory. \n");
	  printf("|  >shv  : set Hardware version. \n");
	  printf("|  >gsv  : get Software version. \n");

	  printf("+-----------------------------------------------------------+\n>");
#endif
}


//Get Parameter Value/////////////////////////////////////////////////////////////////
void GetADCParam()
{
}
//Get ADC Channel Value
uint32_t 	GetAdcValue(uint8_t  gCHNum,uint16_t AccCnt )
{
		 uint32_t ADCVal = 0;
	int i = 0;
	for(i=0;i<AccCnt;i++)
	{
    ADC->ADSR = ADC_ADSR_ADF_Msk;
    _ADC_START_CONVERT();        
    _ADC_WAIT_COVERSION_DONE();

		ADCVal += _ADC_GET_CONVERSION_DATA(gCHNum);
}
    return  ADCVal;
	
   }

void _UART_SENDBINARY(void)
{
	static u16 TxPos = 0;
	static u32 timer = 0;
	if(g_BinTXCount  == 0 || !CheckTimeOver(100, timer)) return;
	timer = MS_TIMER; 

	{
			
		int i= 0;
	
	for(i = 0;i<16;i++)
	{						
	//   	printf("%c",g_u8BinTxData[TxPos++]);
  		_UART_SENDBYTE(UART1,	g_u8BinTxData[TxPos++]);			
			if(TxPos >= g_BinTXCount) 
			{
				TxPos = 0;
				g_BinTXCount = 0;
				return;
			}					
			
			
			
			
	}
}
}


	#define MOD_OP_ADDRESS		0x00
	#define MOD_MD_ADDRESS	0x100
	#define MOD_SP_ADDRESS		0x200
	#define MOD_MP_ADDRESS	0x300
//*---------------------------------------------------------------------------------------------------------*/
/* UART Callback function                                                                                  */
/*---------------------------------------------------------------------------------------------------------*/
// Protocol ���� 
//0x22(1) + SlaveAddress(2) + opCode + Address(2) + Data(2) + CRC16(2) + 0x23(1)
void BinaryProtocal(uint8_t u8InChar)
{
		                    static u32     timer = 0;
                    static u32     rxlen = 0;
                    static u8     modeCnt = 0;

                    u32                          txlen = 0;
                    u8                              ErrorCode = 0;
                    u8                              dFlash = 0;
    
                    uint8_t *RxData = g_u8BinRxData;
                    uint8_t *TxData = g_u8BinTxData;
                   
                    uint16_t crc;
                   
                    uint16_t Data;
                    uint16_t Address,AddressEnd;
                    uint16_t TAddress;    
                    uint16_t *buf = 0;
                   
                    if(CheckTimeOver(100, timer))//30ms

                    {         
                                   if(u8InChar =='\r')
                                   {
                                        modeCnt ++;
                                        if(modeCnt >=8 )Terminal_Enable = 1;
                                   }
                              rxlen = 0;
                    }
                    else
                    {
                             
                              modeCnt = 0;
                              Terminal_Enable = 0;
                    }
                    timer = MS_TIMER;

                    if (rxlen==0 && u8InChar != 0x22)// STX �˻�
                    {
                              return;
                    }    
                    p_LED3= 0;
                    RxData[rxlen] = u8InChar;
                    rxlen++;
                   
                    if (rxlen < 11 || !(RxData[10]     == 0x23))return;                        
                   
                    if(( (RxData[1]     == (_sp.sa>>8) ) && ( RxData[2]     == (_sp.sa & 0xFF) || RxData[2]     == 0xFF ) )
                         || (RxData[1]  == 0xFF && RxData[2]  == 0xFF)
                           || (RxData[1]  == 0xFF && RxData[2]  == 0xFE) ) {} //pass
                    else
                    {
                              rxlen=0;              
                              return;
                    }

                   
                   
                    // CRC ����
                    crc = CRC16(&RxData[1], rxlen - 4);

                    if ( !(RxData[3] == 3  ||RxData[3] == 6 ) )ErrorCode = 1;
                    else if ( RxData[3] <= 4  && (RxData[6] > 0  || RxData[5] > 0x8F))ErrorCode = 3; //��û ������ ����  256 byte�� �̻� �ʰ�
               else if (crc != (uint16_t)(RxData[rxlen - 2] << 8 | (RxData[rxlen - 3] & 0xFF)))ErrorCode = 5;
                   
                    if(ErrorCode ==0)
                    {
                                             Address       =  RxData[4]<<8 | RxData[5];    
                                                 
                                             Data                      =  RxData[6]<<8 | RxData[7];

                                             if(RxData[3] == 3)
                                                       AddressEnd       =  Address + Data ;    
                                             else
                                                       AddressEnd       =  Address;
                                                      
                                             if(Address >= MOD_OP_ADDRESS && AddressEnd <=(sizeof(_op)/2 + MOD_OP_ADDRESS))
                                             {    
                                                       buf = (uint16_t*)&_op;
                                                  TAddress = Address -  MOD_OP_ADDRESS;
                                                       if( TAddress> 1 ) Data = 1;
                                             }
                                             else if(Address >= MOD_MD_ADDRESS && AddressEnd <=(sizeof(_md) + MOD_MD_ADDRESS))
                                             {    
                                                       buf = (uint16_t*)&_md;
                                                  TAddress = Address -  MOD_MD_ADDRESS;

                                                  if(RxData[3] == 6)
                                                       {
                                                                 ErrorCode = 6;
                                                       }
                                             }

                                             else if(Address >= MOD_SP_ADDRESS && AddressEnd <= (sizeof(_sp)/2 + MOD_SP_ADDRESS))
                                             {    
                                                       buf = (uint16_t*)&_sp;                             
                                                  TAddress = Address -  MOD_SP_ADDRESS;
                                                  if( RxData[3] == 6  && TAddress == 0);
                                                  else if( RxData[3] == 6 && (_op.wen == 0 || buf == &_sp.SWver))
                                                       {
                                                                 ErrorCode = 6;
                                                       }                   
                                             }
                                             else if(Address >=MOD_MP_ADDRESS && AddressEnd <= (sizeof(_mp)/2 + MOD_MP_ADDRESS))
                                             {    
                                                       buf = (uint16_t*)&_mp;
                                                  TAddress = Address -  MOD_MP_ADDRESS;
                                             }
                                             else
                                             {
                                                  ErrorCode = 7;
                                             }
                    }
                                       
                         if(RxData[3] == 3 )
                              {
                                        memcpy(TxData,RxData,4);
                                        if(ErrorCode >0)
                                        {         
                                             txlen = 8;                   
                                             TxData[3] = RxData[3]|0x80;                   
                                             TxData[4] = 1;          
                                             TxData[5] = ErrorCode;
                                        }
                                        else
                                        {                                            
                                             txlen = Data * 2 + 8;
                                             TxData[4] = (Data*2)&(0xFF);          
                                             memcpy(&TxData[5],&buf[TAddress],Data*2);

                                             {
                                                  if(Data > 2 &&  buf == (uint16_t*)&_md) // 4bit Data bit swap
                                                  {
                                                                 int i=0; u8 temp1,temp2;

                                                                 for(i = 0; i < Data*2 ; i+=4)
                                                                 {
                                                                          
                                                                           temp1 = TxData[i+5];
                                                                           temp2= TxData[i+6];
                                                                           TxData[i+5] = TxData[i+8];
                                                                           TxData[i+6] = TxData[i+9];
                                                                           TxData[i+7] = temp2;
                                                                           TxData[i+8] = temp1;
                                                                     
                                                            }    
                                                  }
                                                  else
                                                  {
                                                                      int i=0;
                                                                      u8 temp;
                                                                      for(i = 0;i<Data*2;i+=2)
                                                                      {
                                                                                temp = TxData[i+5];
                                                                                TxData[i+5] = TxData[i+6] ;
                                                                                TxData[i+6] = temp;
                                                                 }                                                      
                                                  }
                                                 
                                             }
                                            
                                               crc = CRC16(&TxData[1], txlen - 4);
                                                  TxData[txlen-3] =  crc&0xFF;
                                               TxData[txlen-2] =  (crc >> 8)&0xFF;
                                               TxData[txlen-1] =  0x23;
                                            
                                        }

                              }
                        
                         else
                                   {
                                             memcpy(TxData,RxData,rxlen);
                                             txlen = rxlen;
                                             if(ErrorCode >0)
                                             {
                                                  txlen = 8;
                                                  TxData[3] |= 0x80;                                                            
                                                  TxData[4] =1;          
                                                  TxData[5] = ErrorCode;
                                                 
                                                  crc = CRC16(&TxData[1], txlen - 4);
                                                  TxData[txlen-3] =  crc&0xFF;
                                               TxData[txlen-2] =  (crc >> 8)&0xFF;
                                               TxData[txlen-1] =  0x23;
                                                 
                                             }
                                                                                    
                                             if(ErrorCode == 0 && RxData[3] == 6)
                                             {
                                                       buf[TAddress] = Data;
                                                 
                                                  if((buf == (uint16_t*)&_sp) && _op.wen == 1)SaveSysParam();
                                             }                                            
                              }
                    
                    p_LED3= 1;
															
                    if( ( (TxData[1]     == (_sp.sa>>8) ) &&  TxData[2]     == (_sp.sa & 0xFF) ) || (TxData[2] == 0xFF && _sp.sa == 0x01)||(TxData[1]  == 0xFF && TxData[2]  == 0xFE) || Address  == 0x200)
                    {
                        
                         g_BinTXCount = txlen;
                    }
                             
                 if(_op.SaveFlash  >= 1)
                    {
                              SaveParam();
                         _op.SaveFlash  = 0;
                    }
                    else if(_op.Reset  >= 1)
                    {
                         NVIC_SystemReset();                        
                    }

                    rxlen=0;              
}


void SerialProtocal(uint8_t u8InChar)
{
	/*					static uint8_t Error = 0;
						int rval = 0;
						uint8_t bOK = 0;

            printf("%c", u8InChar);
          
						if(u8InChar == ' ') return;
					
						if(u8InChar == 27)
						{
							memset( g_u8RecData,0,RXBUFSIZE);
							g_i32pointer = 0;
							printf("\r\n>");
							return;
					
						}
					
            if(u8InChar == '\r')   
            { 							
								printf("\n");

							if(Error == 1 )
								{
									Error = 0;
									memset( g_u8RecData,0,RXBUFSIZE);		
									printf("Error\r\n>");
									return;
								}
							
							  rval =  GetIntVal(g_u8RecData);

								if(g_u8CommData[0]=='s')bOK= 1;
								else if(g_u8CommData[0]=='g')bOK= 0;
																		
								 if(strcmp(g_u8CommData,"h")==0)
								{
										PrintInitText ();
										bOK = 0;
								}
								else if(strcmp(g_u8CommData,"rst")==0)
								 {
									   NVIC_SystemReset();
								 }
								  else if(strcmp(g_u8CommData,"ini")==0)
								 {
											SYS_UnlockReg();
											FMC_Erase(DATAFLASH_BASE + PAGE_SIZE);
											Sleep(100);			
											SYS_LockReg();
									   NVIC_SystemReset();
								 }
	
								 else if(strcmp(g_u8CommData,"spd")==0)
								{
										SaveParam();
								} 

								
								else if(strcmp(g_u8CommData,"gmn")==0)  //�𵨸�  
								{
									printf("IDCELL_BT01");
								}
								
								else if(strcmp(g_u8CommData,"gvl")==0)  //���� ����  
								{int val = spiRead((uint8_t )rval,3);
									printf("%d 0x%X",val,val);
								}
			
								else if(strcmp(g_u8CommData,"gzx")==0)  //���� ����  
								{int val = p_ZXIN;
									printf("%d ",val);
								}
								else if(strcmp(g_u8CommData,"gpa")==0)  //���� ����  
								{
									printf("%4.2f ",pValA);
								}
								else if(strcmp(g_u8CommData,"gpv")==0)  //���� ����  
								{printf("%4.2f ",pValVA);
								}
								else if(strcmp(g_u8CommData,"gpf")==0)  //���� ����  
								{printf("%4.2f ",pValFreq);
								}
								
//								else if(strcmp(g_u8CommData,"sc1")==0) p_sCAL1 = (rval==0 ) ? 0 :1;
//								else if(strcmp(g_u8CommData,"sc2")==0) p_sCAL2 = (rval==0 ) ? 0 :1;
								else if(strcmp(g_u8CommData,"ssw")==0) p_RLYSW = (rval==0 ) ? 0 :1;
								
								else if(strcmp(g_u8CommData,"s09")==0) spiWrite(0x09,rval,2);
								else if(strcmp(g_u8CommData,"s0a")==0) spiWrite(0x0A,rval,2);
								else if(strcmp(g_u8CommData,"s0d")==0) spiWrite(0x0D,rval,1);
								else if(strcmp(g_u8CommData,"s0e")==0) spiWrite(0x0E,rval,1);
								else if(strcmp(g_u8CommData,"s0f")==0) spiWrite(0x0F,rval,1);
								else if(strcmp(g_u8CommData,"s10")==0) spiWrite(0x10,rval,1);
								else if(strcmp(g_u8CommData,"s11")==0) spiWrite(0x11,rval,2);
								else if(strcmp(g_u8CommData,"s12")==0) spiWrite(0x12,rval,2);
								else if(strcmp(g_u8CommData,"s13")==0) spiWrite(0x13,rval,1);
								else if(strcmp(g_u8CommData,"s18")==0) spiWrite(0x18,rval,2);
								else if(strcmp(g_u8CommData,"s19")==0) spiWrite(0x19,rval,2);
								else if(strcmp(g_u8CommData,"s1a")==0) spiWrite(0x1A,rval,2);
								else if(strcmp(g_u8CommData,"s1b")==0) spiWrite(0x1B,rval,1);
								else if(strcmp(g_u8CommData,"s1c")==0) spiWrite(0x1C,rval,2);
								else if(strcmp(g_u8CommData,"s1d")==0) spiWrite(0x1D,rval,2);
									
								
								else 
								{
									bOK = 2;
								}

								
								if(bOK == 1)
								{
									printf("OK\r\n>",rval);
								}
								else if(bOK == 2)
								{
									printf(">",rval);
								}

								else 
								{
										printf("\r\n>");
								}

								memset( g_u8RecData,0,RXBUFSIZE);		
								memset(g_u8CommData,0,4);
								g_i32pointer = 0;

							return;
						}
						

						if(g_i32pointer < 3) //command
						{	
										g_u8CommData[g_i32pointer ] = u8InChar;
										g_i32pointer++;
						}
						
						else  if(g_i32pointer < RXBUFSIZE )
            {
							if (u8InChar == ' ' ||u8InChar == '.' )
							{
							}
							else if( ( u8InChar >= '0' && u8InChar <= '9') || u8InChar == '-' ||u8InChar == '+' )
							{
									
									g_u8RecData[g_i32pointer-3] = u8InChar;
									g_i32pointer++;
							}
							else
							{
									Error = 1;
							}
						} 
			
		*/				
}

//***************************************************************************************************************
//  �־��� �ð��� ����Ǿ����� Ȯ���Ѵ�. 1ms ���� 
//***************************************************************************************************************

//duty ������ �̿��Ͽ� Current�� �����Ѵ�.
// mA ������ �Է�


int CheckTimeOver(u32 ms, u32 OldTime)
{
  volatile u32 timer;
	volatile u32 Ptime;
 
	timer = MS_TIMER;               

	Ptime = 	((u32) OldTime + ms);

	if (OldTime > timer)
	{
			//timer = ((u32) timer + 0x100000000);  		
			timer += ((0xFFFFFFFF - OldTime) + 1);
			Ptime = ms;
		  OldTime = 0;
	}
                  
	return ( timer >= Ptime ) ? (timer-OldTime): 0;
	
}

int stoi(char * val)
{
	int intdata=0;
	int i = 0;
	
	int  sign = 1;
	
	for(i=0 ; i<128  ; i++)
	{
		if(i==0)
		{
				if( val[0] == '-')
				{
					sign = -1;
					continue;
				}
				else if( val[0] == '+')continue;				
		}
		if(val[i]==' ')continue;
		
    if( (val[i+1] - '0') > 9 || (val[i+1] - '0') < 0)
		{	
		    intdata += ( val[i]-'0');
			  break;
		}
		else   
			{
			  intdata += ( val[i]-'0');
				intdata *=10;
			};
	}

	return intdata*sign;
}



void UART0_IRQHandler(void)
{
		static u32 DCnt = 0;
	  uint8_t u8InChar=0xFF;
    uint32_t u32IntSts= UART0->ISR;
 
	if(u32IntSts & UART_ISR_RDA_INT_Msk)
    {
        /* Get all the input characters */
        while(_UART_IS_RX_READY(UART0)) 
        {
            /* Get the character from UART Buffer */
            _UART_RECEIVEBYTE(UART0,u8InChar);           /* Rx trigger level is 1 byte*/ 					
						g_u8RCO2Data[DCnt++]=u8InChar;
					
				}			
            if(u8InChar == '\n' )   
            { 							
   						printf("%s", 	g_u8RCO2Data);
							
							CO2_Val =  stoi(g_u8RCO2Data);
							
							//printf("%d\r\n", CO2_Val);
							
							memset(g_u8RCO2Data, 0 , 128);
							DCnt = 0;
						}
        }
}

void Beep(int Freq,int duration)
{
       int PWMVAL = 10000000/Freq;
       PWMA->CNR0= PWMVAL - 1;
    PWMA->CMR0= PWMVAL/2 - 1;
    
          PWMA->PCR |=  PWM_PCR_CH0EN_ENABLE;
       SYS->P2_MFP &= ~SYS_MFP_P20_GPIO;
          SYS->P2_MFP |= SYS_MFP_P20_PWM0;
    
       Sleep(duration);

       SYS->P2_MFP &= ~SYS_MFP_P20_PWM0;
          SYS->P2_MFP |= SYS_MFP_P20_GPIO;
       p_BUZZ = 0;
         
}

void Run_LED(void)
{
	static u32 timer = 0;
	static u8 LEDBlink = 0;

if(CO2_Val<800)
	{
			if(!CheckTimeOver(10000, timer)) return;
			timer = MS_TIMER; 
		
		  p_LEDB = (LEDBlink%6!=0);
		  p_LEDR = 1;
		  p_LEDG = 1;		
	}
  else if(CO2_Val<1000)
	{
			if(!CheckTimeOver(30, timer)) return;
			timer = MS_TIMER; 
		
		  p_LEDB = (LEDBlink%2!=0);
		  p_LEDR = 1;
		  p_LEDG = 1;		
	}
	else if(CO2_Val<1300)
	{
	
			if(!CheckTimeOver(30, timer)) return;
			timer = MS_TIMER; 
		
			p_LEDB = 1;
		  p_LEDR = 1;
		  p_LEDG = (LEDBlink%2!=0);

	}
	else if(CO2_Val<1600)
	{
	  	if(!CheckTimeOver(30, timer)) return;
			timer = MS_TIMER; 
	
			p_LEDB = 1; 
 		  p_LEDR = (LEDBlink%2!=0);
   	  p_LEDG = (LEDBlink%4!=0);
	}
	else if(CO2_Val<2000)
	{
	
			if(!CheckTimeOver(30, timer)) return;
			timer = MS_TIMER; 
		
			p_LEDB = 1;
		  p_LEDR = (LEDBlink%2!=0);
		  p_LEDG = 1;
	}
	
	else 
	{
	  	if(!CheckTimeOver(10000, timer)) return;
			timer = MS_TIMER; 
			p_LEDB = 1;
		  p_LEDR = LEDBlink ;
		  p_LEDG = 1;
		  Beep(1000,100);
	}
	
	LEDBlink+=1;
	    
}
void UART1_IRQHandler(void)
{
    uint8_t u8InChar=0xFF;
    uint32_t u32IntSts= UART1->ISR;
 
	
	if(u32IntSts & UART_ISR_RDA_INT_Msk)
    {
        /* Get all the input characters */
        while(_UART_IS_RX_READY(UART1)) 
        {
            /* Get the character from UART Buffer */
            _UART_RECEIVEBYTE(UART1,u8InChar);           /* Rx trigger level is 1 byte*/ 
					
					BinaryProtocal(u8InChar);

					#ifdef PRINTF_EN 				
					if(Terminal_Enable )
						SerialProtocal(u8InChar);
				#endif

        }
    }
}


void spiWrite(uint8_t Address, int Data,uint8_t Len)
{
	
		p_sCLK= 0;
	  p_sDout = 0;
	  p_sCS = 1;
	
	SYS_SysTickDelay(SPI_DIV) ;p_sCS = 0;
	
	Address &= 0x3F;
	Address |= 0x80;
{int i=0;
		for(i=0;i<8;i++)
		{
		p_sDout = ((Address & (0x1<<(7-i)))==0) ? 0 : 1;
			SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 1;
			SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 0;
		}
			
	 p_sDout = 0;
	for(i=0;i<(Len*8);i++)
	{

		p_sDout = (Data & (0x1<<((Len*8-1)-i)))==0 ? 0 : 1;			
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 1;
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 0;
	}
}
SYS_SysTickDelay(SPI_DIV) ;p_sCS = 1;
SYS_SysTickDelay(SPI_DIV) ;
}

int spiRead(uint8_t Address, uint8_t Len)
{
	int rVal = 0;

	p_sDout = 0;
	p_sCLK  = 0;
	p_sCS   = 1;
	SYS_SysTickDelay(SPI_DIV) ;p_sCS = 0;
	
	Address &= 0x3F;
{int i=0;
	for(i=0;i<8;i++)
	{
		p_sDout = ((Address & (0x1<<(7-i)))==0) ? 0 : 1;
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 1;		
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 0;
	}

	p_sDout = 0;
	for(i=0;i<(Len*8);i++)
	{
		int bVal = 0;
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 1;
		SYS_SysTickDelay(SPI_DIV) ;p_sCLK = 0;
		
		if(i!=0)rVal <<= 1;
		rVal |=  p_sDin;
	}
}
  SYS_SysTickDelay(SPI_DIV) ;p_sCS = 1;

	return rVal;
}

void DAQ_ADC_CONV()
{
  /* 
	double CVal,VVal;
	
		if(_op.VoltageMesStart==0 || g_BinTXCount>0 )return;
		
		 Sleep(50);
	
			CVal =((double)((int)(GetAdcValue(3,256))/125.75)*(_sp.CGain/10000.0)); 
			VVal =((double)(GetAdcValue(0,256)/51.2295)*(_sp.VGain/10000.0)); 
	
		_md.Current = CVal +_sp.COffset;		
		_md.Volt = VVal +_sp.VOffset;
		_op.VoltageMesStart = 0;
			p_LED1 = 0;
		  Sleep(10);
			p_LED1 = 1;	
*/						
	}
void LEDTest()
{
       int n= 0;
         
          // LED Test
          for(n=0;n<3;n++)
          {
          p_LEDR = 0; p_LEDG = 1; p_LEDB  =  1;
          Sleep(500);
          p_LEDR = 1; p_LEDG = 0; p_LEDB  =  1;
          Sleep(500);
          p_LEDR = 1; p_LEDG = 1; p_LEDB  =  0;
          Sleep(500);
          }
p_LED1 = 1; p_LED2 = 1; p_LED3  =  1;
}

void LEDOrange()
	{

	static u32 timer = 0;
	static u8 LEDBlink = 0;

	if(!CheckTimeOver(30, timer)) return;
	timer = MS_TIMER; 
	
			p_LEDB =  1;
 		  p_LEDR = (LEDBlink%2!=0);
   	  p_LEDG = (LEDBlink%4!=0);
		LEDBlink+=1;
	}


//*---------------------------------------------------------------------------------------------------------*/
/* MAIN function                                                                                           */
/*---------------------------------------------------------------------------------------------------------*/
int main(void)
{
	

	SYS_Init();
	UART0_Init();
	UART1_Init();

	GPIO_Init();
	TMR0_Init();
//	SPI1_Init();
	PWMA_Init();
  //	SetOutVoltage(0);
	//	PWMB_Init();
  //	ADC_Init();
//	SetResSel(0);
  p_sRLYSW =p_RLYSW= 0;

	//PrintInitText();
  Beep(1000,100);
	LoadParam();
	LEDTest();

Beep(_SOL1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
/*Beep(_LA1,300);Sleep(50);
Beep(_LA1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Sleep(300);

Beep(_SOL1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Beep(_LE1,300);Sleep(50);
Sleep(300);

Beep(_SOL1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_LA1,300);Sleep(50);
Beep(_LA1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_SOL1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Sleep(300);

Beep(_SOL1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Beep(_LE1,300);Sleep(50);
Beep(_MI1,300);Sleep(50);
Beep(_DO1,300);Sleep(50);
*/
	p_RLYSW= 1;
	//spiWrite(0x0F, 0x12,1);//Gain ���� CH2 Gain 2 , CH1 Gain 4 0.125V Ref Voltage
  //spiWrite(0x0F, 0x32,1);//Gain ���� CH2 Gain 2 , CH1 Gain 4 0.125V Ref Voltage
while(1)
	{
		
//		DAQ_ADC_CONV();
		//LEDOrange();
		Run_LED();
		//LEDTest();
	_UART_SENDBINARY();
		Sleep(1);
  }

}
